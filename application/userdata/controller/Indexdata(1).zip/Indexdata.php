<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 2019/1/15
 * Time: 11:38
 */

namespace app\userdata\controller;


use app\admin\controller\Base;
use think\Controller;
use think\Db;

class Indexdata extends Controller
{

	public function index()
	{
		if (request()->isPost()){
			$param = input('param.');
			$info = $this->getIndexData($param);
			if (!$info){
				return ['code'=>0,'msg'=>'获取成功!','data'=>[],'count'=>0,'rel'=>1];exit();
			}
			return ['code'=>0,'msg'=>'获取成功!','data'=>[$info],'count'=>1,'rel'=>1];exit();
		}
		$media = db("media")->where("media_status",'<>',-1)->field("media_ident,media_title")->select();
		return view("index",['media'=>$media]);
	}


	public function getIndexData($param=[])
	{
		if (empty($param)){
			return false;exit();
		}
		//固定参数（数据库本地）
		$param['media_id'] = "csmt";

		if (!empty($param['time'])){
			$startTime = strtotime(trim(explode("/",$param['time'])[0]));
			$endTime   = strtotime(trim(explode("/",$param['time'])[1]));
		}else{
			$startTime = strtotime(date("Ymd"));
			$endTime   = $startTime + 86400;
		}
		$where = [
			["type","like","index"],
			["ident","=",$param['media_id']],
		];
		$count = ceil(($endTime - $startTime)/86400);
		$list = [];
		$times = $endTime;
		for ($i=0;$i<=$count;$i++){
			if ($times >= $startTime){
				$day = date("Ymd",$times);
				$data= Db::connect("mongodbData")->name($day)->where($where)->select();
				if (!empty($data)){
					$list = array_merge($list,$data);
				}
				$times = $times - 86400;
			}
		}

		$list_one = $list_two = $list_three = $list_four = [];
		$timeCount = 0;
		foreach ($list as $m => $n){
			if ($n['type'] == "index"){
				$list_one[] = $n;
				$timeCount += $n['timer'];
			}
			if (strpos($n['type'],"index_") !== false){
				$list_two[] = $n;
			}
			if ($n['type'] == "index_sex"){
				$list_three[] = $n;
			}
			if ($n['type'] == "index_guide"){
				$list_four[] = $n;
			}
		}
		/**************************************************************************************/
		//页面触达数据
		foreach ($list_one as $key => $value){
			$arr_list_one[$key] = $value['userunique'];
		}
		$userData_one = array_count_values($arr_list_one);
		$pv = count($list_one);            //触达pv
		$uv = count($userData_one);        //触达uv
		/*************************************************************************************/
		//首页点击数据
		foreach ($list_two as $k => $v){
			$arr_list_two[$k] = $v['userunique'];
		}
		$userData_two = array_count_values($arr_list_two);
		$PV = count($list_two);         //首页点击pv
		$UV = count($userData_two);     //首页uv
		/************************************************************************************/
		//男女按钮点击
		foreach ($list_three as $k => $v){
			$arr_list_three[$k] = $v['userunique'];
		}
		$userData_three = array_count_values($arr_list_three);
		$pv_sex = count($list_three);
		$uv_sex = count($userData_three);
		/************************************************************************************/
		//新手引导点击
		foreach ($list_four as $k => $v){
			$arr_list_four[$k] = $v['userunique'];
		}
		$userData_four = array_count_values($arr_list_four);
		$pv_new = count($list_four);
		$uv_new = count($userData_four);

		//数据汇总
		$info['vogTime'] = sprintf("%.2f",($timeCount/$uv));     //平均停留时常
		$info['pv'] = $pv;  //首页触达pv
		$info['uv'] = $uv;  //首页触达uv
		$info['PV'] = $PV;  //首页点击pv
		$info['UV'] = $UV;  //首页点击uv
		$info['pv_sex'] = $pv_sex;  //男女切换pv
		$info['uv_sex'] = $uv_sex;  //男女切换uv
		$info['pv_new'] = $pv_new;  //新手引导pv
		$info['uv_new'] = $uv_new;  //新手引导pv
		$info['lose']   = sprintf("%.2f",(1 - ($UV/$uv))); //首页跳出
		return $info;
	}


}